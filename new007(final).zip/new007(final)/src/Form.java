import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Form  extends JFrame implements Observer{
    private final Observable Observable;  ////*
    private JButton shootButton;
    private JPanel Jpanal;
    private JTextField textField1;
    private JSlider slider1;
    private JCheckBox positionCheckBox;
    private JSpinner spinner1;
    private JSpinner spinner2;
    private JTextArea textArea1;
    private JButton missileOperationButton;
    private JButton laserOperationButton;
    private JButton sendButton;
    private JLabel area;

    public Form(Observable Observable) {

        this.Observable = Observable;

        setContentPane(Jpanal);
        setTitle("Helicopter");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(660,400);
        setLocationRelativeTo(null);
        setVisible(true);
        shootButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String message = textField1.getText();
            Observable.sendMessage(Form.class.getSimpleName(), message);
                System.out.println(textField1.getText());

            }
        });


        positionCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (positionCheckBox.isSelected()) {
                   Observable.sendMessage3("Helicopter in Position ");
                } else {
                   Observable.sendMessage3( "Helicopter not in Position");
                }

            }
        });
        sendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String message = textField1.getText();
               Observable.sendMessage(Form.class.getSimpleName(), message);
            }
        });


        spinner2.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent evt) {
                int counterValue = (Integer) spinner2.getValue();
               Observable.set_S_count_F1(counterValue);
                // You can now use counterValue as needed
            }
        });


        spinner1.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent evt) {
                int counterValue = (Integer) spinner1.getValue();
               Observable.set_A_count_F1(counterValue);
                // You can now use counterValue as needed
            }
        });



        slider1.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent evt) {
                int waterLevel2 = slider1.getValue();
              Observable.set_F_count_F1(waterLevel2);
            }
        });


    }


    @Override
    public void update(int sliderData) {


        if (sliderData > 20) {
            shootButton.setEnabled(true);
        } else {
            shootButton.setEnabled(false);
        }


        if (sliderData > 40) {
            missileOperationButton.setEnabled(true);
        } else {
            missileOperationButton.setEnabled(false);
        }



        if (sliderData > 80) {
            laserOperationButton.setEnabled(true);
        } else {
            laserOperationButton.setEnabled(false);
        }






    }

    @Override
    public void update2(int waterLevel2) {

    }

    @Override
    public void update3(int waterLevel3) {

    }

    @Override
    public void update4(int waterLevel4) {

    }

    @Override
    public void update5(int o2) {

    }

    @Override
    public void Ammo_update_F1(int Ammo) {

    }

    @Override
    public void Ammo_update_F2(int Ammo2) {

    }

    @Override
    public void Ammo_update_F3(int Ammo3) {

    }

    @Override
    public void Fule_update_F1(int Fule3) {

    }

    @Override
    public void Fule_update_F2(int Fule2) {

    }

    @Override
    public void Fule_update_F3(int Fule3) {

    }

    @Override
    public void receiveMessage(String senderClassName, String message) {
        textArea1.append(senderClassName + ": " + message + "\n");
    }

    @Override
    public void receiveMessage2(String message) {
        area.setText(message);
    }

    @Override
    public void receiveMessage3(String message) {

    }

    @Override
    public void receiveMessageP2(String message) {

    }

    @Override
    public void receiveMessageP3(String message) {

    }
}




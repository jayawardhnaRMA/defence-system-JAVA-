import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

public class Form4 extends JFrame implements Observer{
    private final Observable Observable;
    private JComboBox box;
    private JButton collectInformationsButton;
    private JSlider slider1;
    private JTextArea textArea1;
    private JTextArea textArea2;
    private JTextArea textArea3;
    private JCheckBox sendPrivetCheckBox;
    private JCheckBox areaClearCheckBox;
    private JButton button2;
    private JLabel ruler;
    private JPanel Jpanel;
    private JLabel SoldierCount;
    private JLabel FuleAmount;
    private JLabel AmmoAmount;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;


    private int waterLevel2;
    private int waterLevel3;
    private int waterLevel4;

    private int AmmoH;
    private int AmmoT;
    private int AmmoS;


    private int FuleH;
    private int FuleT;
    private int FuleS;

    public Form4(Observable Observable) {
        
        this.Observable = Observable;
        
        
        setContentPane(Jpanel);
        setTitle("MainController");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(660,400);
        setLocationRelativeTo(null);
        setVisible(true);


        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String message = textArea3.getText();
              Observable.sendMessage(Form4.class.getSimpleName(), message);
                System.out.println(textArea3.getText());

            }
        });
        areaClearCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (areaClearCheckBox.isSelected()) {
                  Observable.sendMessage2("Area Cleared");
                } else {
                    Observable.sendMessage2( "Area Not Cleared");
                }
            }
        });


        slider1.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent evt) {
                int waterLevel = slider1.getValue();
               Observable.set_sliderData(waterLevel);
            }
        });



        collectInformationsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SoldierCount.setText(" ") ;
                FuleAmount.setText(" ") ;
                AmmoAmount.setText(" ") ;

            }
        });


        box.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String selectedSpinner = (String) box.getSelectedItem();
                if (selectedSpinner != null) {
                    if (selectedSpinner.equals("Tank")) {
                        SoldierCount.setText("Tank: " + waterLevel2);
                        AmmoAmount.setText("Tank: " + AmmoT);
                        FuleAmount.setText("Tank: " +FuleT );

                    } else if (selectedSpinner.equals("Submarine")) {
                        SoldierCount.setText("Submarine: " + waterLevel3);
                        AmmoAmount.setText("Submarine: " + AmmoS);
                        FuleAmount.setText("Submarine: " +FuleS );

                    }
                    else if (selectedSpinner.equals("Helicopter")) {
                        SoldierCount.setText("Helicopter: " + waterLevel4);
                        AmmoAmount.setText("Helicopter: " + AmmoH);
                        FuleAmount.setText("Helicopter: " +FuleH );
                    }
                }
            }
        });
    }

    @Override
    public void update(int sliderData) {

    }

    @Override
    public void update2(int waterLevel2) {
       // SoldierCount.setText(waterLevel2 + "");
        this.waterLevel2 =waterLevel2;
        displayTotal();
    }

    @Override
    public void update3(int waterLevel3) {
       //SoldierCount.setText(waterLevel3 + "");
        this.waterLevel3 =waterLevel3;
        displayTotal();
    }

    @Override
    public void update4(int waterLevel4) {
       // SoldierCount.setText(waterLevel4 + "");
        this.waterLevel4 =waterLevel4;
        displayTotal();
    }

    @Override
    public void update5(int o2) {

    }

    @Override
    public void Ammo_update_F1(int AmmoH) {
       // AmmoAmount.setText(AmmoH + "");
        this.AmmoH=AmmoH;
        displayTotal2();
    }

    @Override
    public void Ammo_update_F2(int AmmoT) {
        //AmmoAmount.setText(AmmoT + "");
        this.AmmoT=AmmoT;
        displayTotal2();
    }

    @Override
    public void Ammo_update_F3(int AmmoS) {
       // AmmoAmount.setText(AmmoS + "");
        this.AmmoS=AmmoS;
        displayTotal2();
    }

    @Override
    public void Fule_update_F1(int FuleH) {
       // FuleAmount.setText(FuleH + "");
        this.FuleH = FuleH;
        displayTotal3();
    }

    @Override
    public void Fule_update_F2(int FuleT) {
       // FuleAmount.setText(FuleT + "");
        this.FuleT = FuleT;
        displayTotal3();
    }

    @Override
    public void Fule_update_F3(int FuleS) {
       // FuleAmount.setText(FuleS + "");
        this.FuleS = FuleS;
        displayTotal3();
    }


    private void displayTotal() {
        int total = waterLevel2 + waterLevel3 + waterLevel4;
        SoldierCount.setText("Total: " + total);
    }

    private void displayTotal2() {
        int total = AmmoH + AmmoT + AmmoS;
        AmmoAmount.setText("Total: " + total);
    }


    private void displayTotal3() {
        int total = FuleH + FuleT + FuleS;
        FuleAmount.setText("Total: " + total);
    }


    @Override
    public void receiveMessage(String senderClassName, String message) {
        textArea1.append(senderClassName + ": " + message+ "\n");
    }

    @Override
    public void receiveMessage2(String message) {

    }

    @Override
    public void receiveMessage3(String message) {
       textField1.setText(  message+ "\n");
    }

    @Override
    public void receiveMessageP2(String message) {
        textField2.setText(  message+ "\n");
    }

    @Override
    public void receiveMessageP3(String message) {
        textField3.setText(  message+ "\n");
    }
}

public class class2 {
    public static void main(String[] args) {

        Observable Observable = new Observable();
         // new Form(waterLevelObservable);
        // new Form3(waterLevelObservable);
        //  new Form4(waterLevelObservable);

       Observable.addObserver(new Form2(Observable));
       Observable.addObserver(new Form(Observable));
       Observable.addObserver(new Form3(Observable));
       Observable.addObserver(new Form4(Observable));

    }
}





interface Observer {
    void update(int sliderData);

    void update2(int S_count_F2);

    void update3(int waterLevel3);

    void update4(int waterLevel4);

    void update5(int o2);

    void Ammo_update_F1(int Ammo1);

    void Ammo_update_F2(int Ammo2);

    void Ammo_update_F3(int Ammo3);

    void Fule_update_F1(int Fule1);

    void Fule_update_F2(int Fule2);
    void Fule_update_F3(int Fule3);

    void receiveMessage(String senderClassName, String message);

    void receiveMessage2(String message);
    void receiveMessage3(String message);

    void receiveMessageP2(String message);

    void receiveMessageP3(String message);


}

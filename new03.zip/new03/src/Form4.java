import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

public class Form4 extends JFrame implements WaterLevelObserver{
    private final WaterLevelObservable waterLevelObservable;
    private JComboBox comboBox1;
    private JButton collectInformationsButton;
    private JSlider slider1;
    private JTextArea textArea1;
    private JTextArea textArea2;
    private JTextArea textArea3;
    private JCheckBox sendPrivetCheckBox;
    private JCheckBox areaClearCheckBox;
    private JButton button2;
    private JLabel ruler;
    private JPanel Jpanel;
    private JLabel SoldierCount;


    private int waterLevel2;
    private int waterLevel3;
    private int waterLevel4;

    public Form4(WaterLevelObservable waterLevelObservable) {
        
        this.waterLevelObservable = waterLevelObservable;
        
        
        setContentPane(Jpanel);
        setTitle("akila");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(660,400);
        setLocationRelativeTo(null);
        setVisible(true);


        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String message = textArea3.getText();
                waterLevelObservable.sendMessage(Form4.class.getSimpleName(), message);
                System.out.println(textArea3.getText());

            }
        });
        areaClearCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (areaClearCheckBox.isSelected()) {
                    waterLevelObservable.sendMessage2("Area Cleared");
                } else {
                    waterLevelObservable.sendMessage2( "Area Not Cleared");
                }
            }
        });


        slider1.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent evt) {
                int waterLevel = slider1.getValue();
                waterLevelObservable.set_sliderData(waterLevel);
            }
        });




    }

    @Override
    public void update(int sliderData) {

    }

    @Override
    public void update2(int waterLevel2) {
       // SoldierCount.setText(waterLevel2 + "");
        this.waterLevel2 =waterLevel2;
        displayTotal();
    }

    @Override
    public void update3(int waterLevel3) {
       // SoldierCount.setText(waterLevel3 + "");
        this.waterLevel3 =waterLevel3;
        displayTotal();
    }

    @Override
    public void update4(int waterLevel4) {
       // SoldierCount.setText(waterLevel4 + "");
        this.waterLevel4 =waterLevel4;
        displayTotal();
    }


    private void displayTotal() {
        int total = waterLevel2 + waterLevel3 + waterLevel4;
        SoldierCount.setText("Total: " + total);
    }



    @Override
    public void receiveMessage(String senderClassName, String message) {
        textArea1.setText(senderClassName + ": " + message);
    }

    @Override
    public void receiveMessage2(String message) {

    }
}

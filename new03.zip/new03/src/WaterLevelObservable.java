import java.util.ArrayList;

class WaterLevelObservable {
    private int  sliderData;
    private int S_count_F2;
    private int S_count_F3;

    private int S_count_F1;


    private final ArrayList<WaterLevelObserver> observerList = new ArrayList<>();

    public void addWaterLevelObserver(WaterLevelObserver ob) {
        observerList.add(ob);
    }

    public void set_sliderData(int waterLevel) {
        this. sliderData = waterLevel;
        notifyObservers();
    }

    public void set_S_count_F2(int waterLevel2) {
        this.S_count_F2 = waterLevel2;
        notifyObservers2();
    }


    public void set_S_count_F3(int waterLevel2) {
        this.S_count_F3 = waterLevel2;
        notifyObservers3();
    }


    public void set_S_count_F1(int waterLevel2) {
        this.S_count_F1 = waterLevel2;
        notifyObservers4();
    }


//    public void set_A_count_F2( String message) {
//        for (WaterLevelObserver ob : observerList) {
//            ob.receiveMessage2(message);
//        }
//    }

    public void sendMessage(String senderClassName, String message) {
        for (WaterLevelObserver ob : observerList) {
            ob.receiveMessage(senderClassName, message);
        }
    }


    public void sendMessage2( String message) {
        for (WaterLevelObserver ob : observerList) {
            ob.receiveMessage2(message);
        }
    }

    private void notifyObservers() {
        for (WaterLevelObserver ob : observerList) {
            ob.update(sliderData);
        }
    }

    private void notifyObservers2() {
        for (WaterLevelObserver ob : observerList) {
            ob.update2(S_count_F2);
        }
    }

    private void notifyObservers3() {
        for (WaterLevelObserver ob : observerList) {
            ob.update3(S_count_F3);
        }
    }

    private void notifyObservers4() {
        for (WaterLevelObserver ob : observerList) {
            ob.update4(S_count_F1);
        }
    }
}


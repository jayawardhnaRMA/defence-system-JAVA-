public class class2 {
    public static void main(String[] args) {

        WaterLevelObservable waterLevelObservable = new WaterLevelObservable();
       // new Form(waterLevelObservable);
       // new Form3(waterLevelObservable);
       //  new Form4(waterLevelObservable);

        waterLevelObservable.addWaterLevelObserver(new Form2(waterLevelObservable));
        waterLevelObservable.addWaterLevelObserver(new Form(waterLevelObservable));
        waterLevelObservable.addWaterLevelObserver(new Form3(waterLevelObservable));
        waterLevelObservable.addWaterLevelObserver(new Form4(waterLevelObservable));

    }
}





interface WaterLevelObserver {
    void update(int sliderData);

    void update2(int S_count_F2);

    void update3(int waterLevel3);

    void update4(int waterLevel4);

    void receiveMessage(String senderClassName, String message);

    void receiveMessage2(String message);
}

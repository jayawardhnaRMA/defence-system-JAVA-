import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Form  extends JFrame implements WaterLevelObserver{
    private final WaterLevelObservable waterLevelObservable;  ////*
    private JButton shootButton;
    private JPanel Jpanal;
    private JTextField textField1;
    private JSlider slider1;
    private JCheckBox checkBox1;
    private JSpinner spinner1;
    private JSpinner spinner2;
    private JTextArea textArea1;
    private JButton missileOperationButton;
    private JButton laserOperationButton;
    private JButton sendButton;
    private JLabel area;

    public Form(WaterLevelObservable waterLevelObservable) {

        this.waterLevelObservable = waterLevelObservable;

        setContentPane(Jpanal);
        setTitle("Helicopter");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(660,400);
        setLocationRelativeTo(null);
        setVisible(true);
        shootButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String message = textField1.getText();
                waterLevelObservable.sendMessage(Form.class.getSimpleName(), message);
                System.out.println(textField1.getText());

            }
        });


        checkBox1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (checkBox1.isSelected()) {
                    waterLevelObservable.sendMessage2("Area Cleared");
                } else {
                    waterLevelObservable.sendMessage2( "Area Not Cleared");
                }

            }
        });
        sendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String message = textField1.getText();
                waterLevelObservable.sendMessage(Form.class.getSimpleName(), message);
            }
        });


        spinner2.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent evt) {
                int counterValue = (Integer) spinner2.getValue();
                waterLevelObservable.set_S_count_F1(counterValue);
                // You can now use counterValue as needed
            }
        });


        spinner1.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent evt) {
                int counterValue = (Integer) spinner1.getValue();
                waterLevelObservable.set_A_count_F1(counterValue);
                // You can now use counterValue as needed
            }
        });



    }


    @Override
    public void update(int sliderData) {


        if (sliderData > 20) {
            shootButton.setEnabled(true);
        } else {
            shootButton.setEnabled(false);
        }


        if (sliderData > 40) {
            missileOperationButton.setEnabled(true);
        } else {
            missileOperationButton.setEnabled(false);
        }



        if (sliderData > 80) {
            laserOperationButton.setEnabled(true);
        } else {
            laserOperationButton.setEnabled(false);
        }






    }

    @Override
    public void update2(int waterLevel2) {

    }

    @Override
    public void update3(int waterLevel3) {

    }

    @Override
    public void update4(int waterLevel4) {

    }

    @Override
    public void Ammo_update_F1(int Ammo) {

    }

    @Override
    public void Ammo_update_F2(int Ammo2) {

    }

    @Override
    public void Ammo_update_F3(int Ammo3) {

    }

    @Override
    public void receiveMessage(String senderClassName, String message) {
        textArea1.setText(senderClassName + ": " + message);
    }

    @Override
    public void receiveMessage2(String message) {
        area.setText(message);
    }
}




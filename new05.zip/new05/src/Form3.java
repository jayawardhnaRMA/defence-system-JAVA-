import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Form3 extends JFrame implements WaterLevelObserver {
    private JPanel panel1;
    private JTextField textField1;
    private JButton sonarOperrationButton;
    private JButton shootButton;
    private JButton tomahawkMissileButton;
    private JButton trident2MissileButton;
    private JLabel area;
    private JTextArea textArea1;
    private JSpinner spinner1;
    private JCheckBox positionCheckBox;
    private JButton button3;
    private JSpinner spinner2;
    private JSlider slider1;
    private JSlider slider2;

    public Form3(WaterLevelObservable waterLevelObservable) {

        setContentPane(panel1);
        setTitle("Submarine");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(660,400);
        setLocationRelativeTo(null);
        setVisible(true);



        button3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String message = textField1.getText();
                waterLevelObservable.sendMessage(Form3.class.getSimpleName(), message);
                System.out.println(textField1.getText());

            }
        });


        spinner1.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent evt) {
                int counterValue = (Integer) spinner1.getValue();
                waterLevelObservable.set_S_count_F3(counterValue);
                // You can now use counterValue as needed
            }
        });

        spinner2.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent evt) {
                int counterValue = (Integer) spinner2.getValue();
                waterLevelObservable.set_A_count_F3(counterValue);
                // You can now use counterValue as needed
            }
        });




        slider1.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent evt) {
                int waterLevel2 = slider1.getValue();
                waterLevelObservable.set_F_count_F3(waterLevel2);
                if(waterLevel2<20){
                    JOptionPane.showMessageDialog(null, "Fuel level is low!", "Alert", JOptionPane.WARNING_MESSAGE);
                }
            }
        });


        
        slider2.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent evt) {
                int waterLevel2 = slider2.getValue();
                waterLevelObservable.set_F_count_F3(waterLevel2);
                if(waterLevel2<20){
                    JOptionPane.showMessageDialog(null, "Fuel level is low!", "Alert", JOptionPane.WARNING_MESSAGE);
                }
            }
        });




    }

    @Override
    public void update(int sliderData) {




        if (sliderData > 20) {
            shootButton.setEnabled(true);
        } else {
            shootButton.setEnabled(false);
        }


        if (sliderData > 40) {
            sonarOperrationButton.setEnabled(true);
        } else {
            sonarOperrationButton.setEnabled(false);
        }



        if (sliderData > 80) {
            tomahawkMissileButton.setEnabled(true);
        } else {
            tomahawkMissileButton.setEnabled(false);
        }



        if (sliderData >= 100) {
            trident2MissileButton.setEnabled(true);
        } else {
            trident2MissileButton.setEnabled(false);
        }


    }

    @Override
    public void update2(int waterLevel2) {

    }

    @Override
    public void update3(int waterLevel3) {

    }

    @Override
    public void update4(int waterLevel4) {

    }

    @Override
    public void Ammo_update_F1(int Ammo) {

    }

    @Override
    public void Ammo_update_F2(int Ammo2) {

    }

    @Override
    public void Ammo_update_F3(int Ammo3) {

    }

    @Override
    public void Fule_update_F1(int Fule3) {

    }

    @Override
    public void Fule_update_F2(int Fule2) {

    }

    @Override
    public void Fule_update_F3(int Fule3) {

    }

    @Override
    public void receiveMessage(String senderClassName, String message) {
        textArea1.append(senderClassName + ": " + message+ "\n");
    }

    @Override
    public void receiveMessage2(String message) {
        area.setText(message);
    }
}
